import Foundation

struct CountedSet<Type: Hashable>: ExpressibleByArrayLiteral {

    init(arrayLiteral elements: Type...) {
        for element in elements {
            self.add(element)
        }
    }

    private var countDictionary: [Type: Int] = [:]

    mutating func add(_ key: Type) {
        if let value = countDictionary[key] {
            countDictionary[key] = value + 1
        } else {
            countDictionary.updateValue(1, forKey: key)
        }
    }

    mutating func delete(_ key: Type) {
        if let value = countDictionary[key] {
            if value > 0 {
                countDictionary[key] = value - 1
            } else {
                countDictionary.removeValue(forKey: key)
            }
        }
    }

    subscript(_ member: Type) -> Int {
        return countDictionary[member] ?? 0
    }

    func count() -> Int {
        return countDictionary.count
    }
}

enum Arrow { case iron, wooden, elven, dwarvish, magic, silver }
var aCountedSet = CountedSet<Arrow>()
aCountedSet[.iron] // 0
var myCountedSet: CountedSet<Arrow> = [.iron, .magic, .iron, .silver, .iron, .iron]
myCountedSet[.iron] // 4
myCountedSet.delete(.iron) // 3
myCountedSet.delete(.dwarvish) // 0
myCountedSet.delete(.magic) // 0

