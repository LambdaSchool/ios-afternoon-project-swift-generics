import UIKit

struct CountedSet<Element: Hashable> {
    private(set) var store: [Element: Int] = [:]
}


extension CountedSet {
    mutating func insert(_ element: Element) {
        self.store[element] = (self.store[element] ?? 0) + 1
    }
    mutating func remove(_ element: Element) {
        let x = (store[element] ?? 0)
        if x > 0 {
            store[element] = x - 1
        }
    }
}

extension CountedSet {
    subscript(_ member: Element) -> Int {
        return store[member] ?? 0
    }
}

extension CountedSet {
    func count() -> Any {
        var counter = 0
        if store.isEmpty {
            return "isEmpty"
        } else {
            counter = store.count
            return counter
        }
    }
}

extension CountedSet: ExpressibleByArrayLiteral {
    typealias ArrayLiteralElement = Element
    init(arrayLiteral elements: Element...) {
          for element in elements {
              store[element] = (store[element] ?? 0) + 1
        }
}
}

// Tests
enum Arrow { case iron, wooden, elven, dwarvish, magic, silver }

var a = CountedSet<Arrow>()

print(a[.iron])

var setfromArray: CountedSet<Arrow> = [.magic, .silver, .dwarvish, .dwarvish, .silver, .silver, .magic, .magic]

print(setfromArray)

setfromArray.remove(.magic)
print(setfromArray[.magic])

setfromArray.insert(.iron)
setfromArray.insert(.iron)
setfromArray.insert(.iron)
setfromArray.insert(.iron)
print(setfromArray[.iron])
